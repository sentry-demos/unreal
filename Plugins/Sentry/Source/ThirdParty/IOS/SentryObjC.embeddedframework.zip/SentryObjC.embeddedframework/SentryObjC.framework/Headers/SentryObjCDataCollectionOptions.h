#if SDK_V10
#    import <Foundation/Foundation.h>
#    if !__has_include(<SentryObjC/SentryObjCDefines.h>)
#        import "SentryObjCDataCollectionHttpBodyType.h"
#    else
#        import <SentryObjC/SentryObjCDataCollectionHttpBodyType.h>
#    endif

@class SentryObjCDataCollectionKeyValueCollectionBehavior;
@class SentryObjCDataCollectionHttpHeaderCollectionOptions;

NS_ASSUME_NONNULL_BEGIN

/// Configuration for what data the SDK collects automatically.
///
/// All properties have spec-defined defaults. Users supply only the options they want to override;
/// omitted fields use the documented defaults.
///
/// Data explicitly set by the user on the scope is not gated by these options.
@interface SentryObjCDataCollectionOptions : NSObject

/// Automatically populate @c user.* fields from auto-instrumentation. Defaults to @c YES.
@property (nonatomic) BOOL userInfo;

/// Controls cookie collection. Defaults to denyList.
@property (nonatomic, strong) SentryObjCDataCollectionKeyValueCollectionBehavior *cookies;

/// Controls HTTP header collection for request and response directions.
@property (nonatomic, strong) SentryObjCDataCollectionHttpHeaderCollectionOptions *httpHeaders;

/// Body types to collect. Defaults to @c SentryObjCDataCollectionHttpBodyTypeAll.
@property (nonatomic) SentryObjCDataCollectionHttpBodyType httpBodies;

/// Controls URL query parameter filtering. Defaults to denyList.
@property (nonatomic, strong) SentryObjCDataCollectionKeyValueCollectionBehavior *urlQueryParams;

- (instancetype)init;

/// Creates data collection options from a dictionary.
///
/// Missing keys and @c NSNull values use the same defaults as @c init.
- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end

NS_ASSUME_NONNULL_END
#endif // SDK_V10
